/***********************************************************************
 * $Id$
 *
 * Project: NXP LPC1850 LCD example.
 *
 * Description: Main application.
 *
 * Copyright(C) 2011, NXP Semiconductor
 * All rights reserved.
 *
 ***********************************************************************
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * products. This software is supplied "AS IS" without any warranties.
 * NXP Semiconductors assumes no responsibility or liability for the
 * use of the software, conveys no license or title under any patent,
 * copyright, or mask work right to the product. NXP Semiconductors
 * reserves the right to make changes in the software without
 * notification. NXP Semiconductors also make no representation or
 * warranty that such application will be suitable for the specified
 * use without further testing or modification.
 **********************************************************************/
#include "LPC18xx.h"
#include "config.h"
#include "lpc18xx_adc.h"

#include "kiosk_usb.h"

/**********************************************************************
 ** Function prototypes
 **********************************************************************/

/**********************************************************************
 ** Local variables
 **********************************************************************/

/**********************************************************************
 ** Function name:
 **
 ** Description:
 **
 ** Parameters:
 **
 ** Returned value:
 **********************************************************************/
typedef enum
{
	KIOSK_SLIDES_LOADED,
	KIOSK_SLIDES_UNLOADED,
}KIOSK_STATE;

KIOSK_STATE kioskState = KIOSK_SLIDES_UNLOADED;

/** Configures the board hardware and chip peripherals for the demo's functionality. */
void SetupHardware(void)
{

	bsp_init();
	TimerInit();

	/* ADC initialize */
	ADC_Init(LPC_ADC0, 200000, 10);
	ADC_IntConfig(LPC_ADC0,ADC_ADINTEN0,DISABLE);
	ADC_ChannelCmd(LPC_ADC0,ADC_CHANNEL_0,ENABLE);

	/* Hardware Initialization */
	Serial_Init(9600, false);
	LEDs_Init();

	/* Create a stdio stream for the serial port for stdin and stdout */
	Serial_CreateStream(NULL);
}


int main (void)
{
	SetupHardware();

	puts_P(PSTR("Kiosk Demo running.\r\n"));

//	emwin_demo();

	kiosk_lcd_init();

  	/* Enable LCD interrupts */
  	NVIC_EnableIRQ(LCD_IRQn);

#if 1
	kiosk_usb_setup();

	while(1)
	{
		switch(kioskState)
		{
		case KIOSK_SLIDES_UNLOADED:
			if (kioskUsbDeviceAttached)
			{
				if (!kiosk_usb_ready())
					break;

				kiosk_usb_load_slides();

				kiosk_usb_run_slides();

				kioskState = KIOSK_SLIDES_LOADED;
			}
			break;
		case KIOSK_SLIDES_LOADED:
			if (!kioskUsbDeviceAttached)
			{
				kiosk_usb_stop_slides();

				kioskState = KIOSK_SLIDES_UNLOADED;
			}
			break;
		}
		kiosk_usb_task();

	}
#endif

}

/**********************************************************************
 **                            End Of File
 **********************************************************************/
